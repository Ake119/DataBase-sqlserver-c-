﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class stuquery : Form
    {
        public stuquery()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.DataSource = null;
        }

        private void txtsno_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtspwd_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string studentId = this.txtsno.Text;
            string password = this.txtspwd.Text;
            string connectionString = "Data Source=. ; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                   
                    string loginQuery = "SELECT * FROM 学生信息表 WHERE 学号=@StudentId AND 密码=@Password";
                    SqlCommand loginCommand = new SqlCommand(loginQuery, connection);
                    loginCommand.Parameters.AddWithValue("@StudentId", studentId);
                    loginCommand.Parameters.AddWithValue("@Password", password);

                    SqlDataReader reader = loginCommand.ExecuteReader();
                    if (reader.Read())
                    {
                        reader.Close(); 
                   
                        string gradeQuery = "SELECT * FROM 成绩表 WHERE 学号=@StudentId";
                        SqlCommand gradeCommand = new SqlCommand(gradeQuery, connection);
                        gradeCommand.Parameters.AddWithValue("@StudentId", studentId);

                      
                        SqlDataAdapter adapter = new SqlDataAdapter(gradeCommand);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;

                        MessageBox.Show("查询成功！");
                    }
                    else
                    {
                        MessageBox.Show("用户名或密码错误，查询失败！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("错误: " + ex.Message);
                }
            }
        }

        private void stuquery_Load(object sender, EventArgs e)
        {
          

        }
    }
}
