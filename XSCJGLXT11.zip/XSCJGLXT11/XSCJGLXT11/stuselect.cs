﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class stuselect : Form
    {
        private string studentId;    
        private string studentName;  
        private string connectionString = "Data Source=. ; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";
        public stuselect(string studentId, string studentName)
        {
            InitializeComponent();
            this.studentId = studentId;
            this.studentName = studentName;
        }

        private void stuselect_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“xSCJGL1DataSet.课程表”中。您可以根据需要移动或移除它。
            this.课程表TableAdapter.Fill(this.xSCJGL1DataSet.课程表);


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtcnoadd_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            string courseId = txtcnoadd.Text.Trim();
            if (string.IsNullOrEmpty(courseId))
            {
                MessageBox.Show("请输入课程号！");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string checkQuery = "SELECT COUNT(*) FROM 选课表 WHERE 学号=@StudentId AND 课程号=@CourseId";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                    checkCmd.Parameters.AddWithValue("@StudentId", studentId);
                    checkCmd.Parameters.AddWithValue("@CourseId", courseId);

                    int exists = (int)checkCmd.ExecuteScalar();
                    if (exists > 0)
                    {
                        MessageBox.Show("你已经选过这门课程了！");
                        return;
                    }

                    
                    string courseQuery = "SELECT 课程名称, 教师姓名 FROM 课程表 WHERE 课程号=@CourseId";
                    SqlCommand courseCmd = new SqlCommand(courseQuery, conn);
                    courseCmd.Parameters.AddWithValue("@CourseId", courseId);

                    SqlDataReader reader = courseCmd.ExecuteReader();
                    if (reader.Read())
                    {
                        string courseName = reader["课程名称"].ToString();
                        string teacherName = reader["教师姓名"].ToString();
                        reader.Close();

                        string insertQuery = @"INSERT INTO 选课表 
                                    (学号, 学生姓名, 课程号, 课程名称, 教师姓名) 
                                    VALUES 
                                    (@StudentId, @StudentName, @CourseId, @CourseName, @TeacherName)";

                        SqlCommand insertCmd = new SqlCommand(insertQuery, conn);
                        insertCmd.Parameters.AddWithValue("@StudentId", studentId);
                        insertCmd.Parameters.AddWithValue("@StudentName", studentName);
                        insertCmd.Parameters.AddWithValue("@CourseId", courseId);
                        insertCmd.Parameters.AddWithValue("@CourseName", courseName);
                        insertCmd.Parameters.AddWithValue("@TeacherName", teacherName);

                        int result = insertCmd.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("选课成功！");
                            
                        }
                        else
                        {
                            MessageBox.Show("选课失败！");
                        }
                    }
                    else
                    {
                        reader.Close();
                        MessageBox.Show("未找到该课程号对应的课程！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("选课失败: " + ex.Message);
                }
            }
        }

        private void txtcnodelete_TextChanged(object sender, EventArgs e)
        {

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string courseId = txtcnodelete.Text.Trim();
            if (string.IsNullOrEmpty(courseId))
            {
                MessageBox.Show("请输入要退选的课程号！");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string deleteQuery = "DELETE FROM 选课表 WHERE 学号=@StudentId AND 课程号=@CourseId";
                    SqlCommand cmd = new SqlCommand(deleteQuery, conn);
                    cmd.Parameters.AddWithValue("@StudentId", studentId);
                    cmd.Parameters.AddWithValue("@CourseId", courseId);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("退选成功！");
                        
                    }
                    else
                    {
                        MessageBox.Show("未找到该选课记录！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("退选失败: " + ex.Message);
                }
            }
        }
    }
    
}
