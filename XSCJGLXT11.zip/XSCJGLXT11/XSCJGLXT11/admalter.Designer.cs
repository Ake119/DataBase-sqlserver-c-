﻿namespace XSCJGLXT11
{
    partial class admalter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label7 = new System.Windows.Forms.Label();
            this.xSCJGL1DataSet = new XSCJGLXT11.XSCJGL1DataSet();
            this.成绩表BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.成绩表TableAdapter = new XSCJGLXT11.XSCJGL1DataSetTableAdapters.成绩表TableAdapter();
            this.课程表BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.课程表TableAdapter = new XSCJGLXT11.XSCJGL1DataSetTableAdapters.课程表TableAdapter();
            this.选课表BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.选课表TableAdapter = new XSCJGLXT11.XSCJGL1DataSetTableAdapters.选课表TableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.学号DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.学生姓名DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.课程号DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.课程名称DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.教师姓名DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.平时成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.末考成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.综合成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.是否修改成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.意见DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.原平时成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.原末考成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.修改时间DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.txtsno = new System.Windows.Forms.TextBox();
            this.txtcno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btncertain = new System.Windows.Forms.Button();
            this.txttime = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtview = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtnewusual = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnnewusual = new System.Windows.Forms.Button();
            this.btnnewlast = new System.Windows.Forms.Button();
            this.txtnewlast = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnoldusual = new System.Windows.Forms.Button();
            this.txtoldusual = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnoldlast = new System.Windows.Forms.Button();
            this.txtoldlast = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.成绩表BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.课程表BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.选课表BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("黑体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(29, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 24);
            this.label7.TabIndex = 16;
            this.label7.Text = "修改成绩";
            // 
            // xSCJGL1DataSet
            // 
            this.xSCJGL1DataSet.DataSetName = "XSCJGL1DataSet";
            this.xSCJGL1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 成绩表BindingSource
            // 
            this.成绩表BindingSource.DataMember = "成绩表";
            this.成绩表BindingSource.DataSource = this.xSCJGL1DataSet;
            // 
            // 成绩表TableAdapter
            // 
            this.成绩表TableAdapter.ClearBeforeFill = true;
            // 
            // 课程表BindingSource
            // 
            this.课程表BindingSource.DataMember = "课程表";
            this.课程表BindingSource.DataSource = this.xSCJGL1DataSet;
            // 
            // 课程表TableAdapter
            // 
            this.课程表TableAdapter.ClearBeforeFill = true;
            // 
            // 选课表BindingSource
            // 
            this.选课表BindingSource.DataMember = "选课表";
            this.选课表BindingSource.DataSource = this.xSCJGL1DataSet;
            this.选课表BindingSource.CurrentChanged += new System.EventHandler(this.选课表BindingSource_CurrentChanged);
            // 
            // 选课表TableAdapter
            // 
            this.选课表TableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.学号DataGridViewTextBoxColumn,
            this.学生姓名DataGridViewTextBoxColumn,
            this.课程号DataGridViewTextBoxColumn,
            this.课程名称DataGridViewTextBoxColumn,
            this.教师姓名DataGridViewTextBoxColumn,
            this.平时成绩DataGridViewTextBoxColumn,
            this.末考成绩DataGridViewTextBoxColumn,
            this.综合成绩DataGridViewTextBoxColumn,
            this.是否修改成绩DataGridViewTextBoxColumn,
            this.意见DataGridViewTextBoxColumn,
            this.原平时成绩DataGridViewTextBoxColumn,
            this.原末考成绩DataGridViewTextBoxColumn,
            this.修改时间DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.选课表BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(33, 80);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(744, 172);
            this.dataGridView1.TabIndex = 17;
            // 
            // 学号DataGridViewTextBoxColumn
            // 
            this.学号DataGridViewTextBoxColumn.DataPropertyName = "学号";
            this.学号DataGridViewTextBoxColumn.HeaderText = "学号";
            this.学号DataGridViewTextBoxColumn.Name = "学号DataGridViewTextBoxColumn";
            // 
            // 学生姓名DataGridViewTextBoxColumn
            // 
            this.学生姓名DataGridViewTextBoxColumn.DataPropertyName = "学生姓名";
            this.学生姓名DataGridViewTextBoxColumn.HeaderText = "学生姓名";
            this.学生姓名DataGridViewTextBoxColumn.Name = "学生姓名DataGridViewTextBoxColumn";
            // 
            // 课程号DataGridViewTextBoxColumn
            // 
            this.课程号DataGridViewTextBoxColumn.DataPropertyName = "课程号";
            this.课程号DataGridViewTextBoxColumn.HeaderText = "课程号";
            this.课程号DataGridViewTextBoxColumn.Name = "课程号DataGridViewTextBoxColumn";
            // 
            // 课程名称DataGridViewTextBoxColumn
            // 
            this.课程名称DataGridViewTextBoxColumn.DataPropertyName = "课程名称";
            this.课程名称DataGridViewTextBoxColumn.HeaderText = "课程名称";
            this.课程名称DataGridViewTextBoxColumn.Name = "课程名称DataGridViewTextBoxColumn";
            // 
            // 教师姓名DataGridViewTextBoxColumn
            // 
            this.教师姓名DataGridViewTextBoxColumn.DataPropertyName = "教师姓名";
            this.教师姓名DataGridViewTextBoxColumn.HeaderText = "教师姓名";
            this.教师姓名DataGridViewTextBoxColumn.Name = "教师姓名DataGridViewTextBoxColumn";
            // 
            // 平时成绩DataGridViewTextBoxColumn
            // 
            this.平时成绩DataGridViewTextBoxColumn.DataPropertyName = "平时成绩";
            this.平时成绩DataGridViewTextBoxColumn.HeaderText = "平时成绩";
            this.平时成绩DataGridViewTextBoxColumn.Name = "平时成绩DataGridViewTextBoxColumn";
            // 
            // 末考成绩DataGridViewTextBoxColumn
            // 
            this.末考成绩DataGridViewTextBoxColumn.DataPropertyName = "末考成绩";
            this.末考成绩DataGridViewTextBoxColumn.HeaderText = "末考成绩";
            this.末考成绩DataGridViewTextBoxColumn.Name = "末考成绩DataGridViewTextBoxColumn";
            // 
            // 综合成绩DataGridViewTextBoxColumn
            // 
            this.综合成绩DataGridViewTextBoxColumn.DataPropertyName = "综合成绩";
            this.综合成绩DataGridViewTextBoxColumn.HeaderText = "综合成绩";
            this.综合成绩DataGridViewTextBoxColumn.Name = "综合成绩DataGridViewTextBoxColumn";
            this.综合成绩DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // 是否修改成绩DataGridViewTextBoxColumn
            // 
            this.是否修改成绩DataGridViewTextBoxColumn.DataPropertyName = "是否修改成绩";
            this.是否修改成绩DataGridViewTextBoxColumn.HeaderText = "是否修改成绩";
            this.是否修改成绩DataGridViewTextBoxColumn.Name = "是否修改成绩DataGridViewTextBoxColumn";
            // 
            // 意见DataGridViewTextBoxColumn
            // 
            this.意见DataGridViewTextBoxColumn.DataPropertyName = "意见";
            this.意见DataGridViewTextBoxColumn.HeaderText = "意见";
            this.意见DataGridViewTextBoxColumn.Name = "意见DataGridViewTextBoxColumn";
            // 
            // 原平时成绩DataGridViewTextBoxColumn
            // 
            this.原平时成绩DataGridViewTextBoxColumn.DataPropertyName = "原平时成绩";
            this.原平时成绩DataGridViewTextBoxColumn.HeaderText = "原平时成绩";
            this.原平时成绩DataGridViewTextBoxColumn.Name = "原平时成绩DataGridViewTextBoxColumn";
            // 
            // 原末考成绩DataGridViewTextBoxColumn
            // 
            this.原末考成绩DataGridViewTextBoxColumn.DataPropertyName = "原末考成绩";
            this.原末考成绩DataGridViewTextBoxColumn.HeaderText = "原末考成绩";
            this.原末考成绩DataGridViewTextBoxColumn.Name = "原末考成绩DataGridViewTextBoxColumn";
            // 
            // 修改时间DataGridViewTextBoxColumn
            // 
            this.修改时间DataGridViewTextBoxColumn.DataPropertyName = "修改时间";
            this.修改时间DataGridViewTextBoxColumn.HeaderText = "修改时间";
            this.修改时间DataGridViewTextBoxColumn.Name = "修改时间DataGridViewTextBoxColumn";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(30, 286);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 18;
            this.label1.Text = "学号：";
            // 
            // txtsno
            // 
            this.txtsno.Location = new System.Drawing.Point(91, 286);
            this.txtsno.Name = "txtsno";
            this.txtsno.Size = new System.Drawing.Size(221, 21);
            this.txtsno.TabIndex = 19;
            this.txtsno.TextChanged += new System.EventHandler(this.txtsno_TextChanged);
            // 
            // txtcno
            // 
            this.txtcno.Location = new System.Drawing.Point(91, 326);
            this.txtcno.Name = "txtcno";
            this.txtcno.Size = new System.Drawing.Size(221, 21);
            this.txtcno.TabIndex = 21;
            this.txtcno.TextChanged += new System.EventHandler(this.txtcno_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(14, 326);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 20;
            this.label2.Text = "课程号：";
            // 
            // btnsearch
            // 
            this.btnsearch.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnsearch.Location = new System.Drawing.Point(92, 365);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(219, 40);
            this.btnsearch.TabIndex = 22;
            this.btnsearch.Text = "查询";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btncertain
            // 
            this.btncertain.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btncertain.Location = new System.Drawing.Point(93, 514);
            this.btncertain.Name = "btncertain";
            this.btncertain.Size = new System.Drawing.Size(219, 40);
            this.btncertain.TabIndex = 27;
            this.btncertain.Text = "确定";
            this.btncertain.UseVisualStyleBackColor = true;
            this.btncertain.Click += new System.EventHandler(this.btncertain_Click);
            // 
            // txttime
            // 
            this.txttime.Location = new System.Drawing.Point(92, 475);
            this.txttime.Name = "txttime";
            this.txttime.Size = new System.Drawing.Size(221, 21);
            this.txttime.TabIndex = 26;
            this.txttime.TextChanged += new System.EventHandler(this.txttime_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(-1, 475);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "修改时间：";
            // 
            // txtview
            // 
            this.txtview.Location = new System.Drawing.Point(92, 435);
            this.txtview.Name = "txtview";
            this.txtview.Size = new System.Drawing.Size(221, 21);
            this.txtview.TabIndex = 24;
            this.txtview.TextChanged += new System.EventHandler(this.txtview_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(31, 435);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "意见：";
            // 
            // txtnewusual
            // 
            this.txtnewusual.Location = new System.Drawing.Point(446, 286);
            this.txtnewusual.Name = "txtnewusual";
            this.txtnewusual.Size = new System.Drawing.Size(221, 21);
            this.txtnewusual.TabIndex = 29;
            this.txtnewusual.TextChanged += new System.EventHandler(this.txtnewusual_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(337, 286);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 16);
            this.label5.TabIndex = 28;
            this.label5.Text = "新平时成绩：";
            // 
            // btnnewusual
            // 
            this.btnnewusual.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnnewusual.Location = new System.Drawing.Point(683, 272);
            this.btnnewusual.Name = "btnnewusual";
            this.btnnewusual.Size = new System.Drawing.Size(124, 45);
            this.btnnewusual.TabIndex = 30;
            this.btnnewusual.Text = "录入平时成绩";
            this.btnnewusual.UseVisualStyleBackColor = true;
            this.btnnewusual.Click += new System.EventHandler(this.btnnewusual_Click);
            // 
            // btnnewlast
            // 
            this.btnnewlast.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnnewlast.Location = new System.Drawing.Point(683, 351);
            this.btnnewlast.Name = "btnnewlast";
            this.btnnewlast.Size = new System.Drawing.Size(124, 45);
            this.btnnewlast.TabIndex = 33;
            this.btnnewlast.Text = "录入末考成绩";
            this.btnnewlast.UseVisualStyleBackColor = true;
            this.btnnewlast.Click += new System.EventHandler(this.btnnewlast_Click);
            // 
            // txtnewlast
            // 
            this.txtnewlast.Location = new System.Drawing.Point(446, 365);
            this.txtnewlast.Name = "txtnewlast";
            this.txtnewlast.Size = new System.Drawing.Size(221, 21);
            this.txtnewlast.TabIndex = 32;
            this.txtnewlast.TextChanged += new System.EventHandler(this.txtnewlast_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(337, 365);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 16);
            this.label6.TabIndex = 31;
            this.label6.Text = "新末考成绩：";
            // 
            // btnoldusual
            // 
            this.btnoldusual.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnoldusual.Location = new System.Drawing.Point(683, 422);
            this.btnoldusual.Name = "btnoldusual";
            this.btnoldusual.Size = new System.Drawing.Size(124, 45);
            this.btnoldusual.TabIndex = 36;
            this.btnoldusual.Text = "录入平时成绩";
            this.btnoldusual.UseVisualStyleBackColor = true;
            this.btnoldusual.Click += new System.EventHandler(this.btnoldusual_Click);
            // 
            // txtoldusual
            // 
            this.txtoldusual.Location = new System.Drawing.Point(446, 436);
            this.txtoldusual.Name = "txtoldusual";
            this.txtoldusual.Size = new System.Drawing.Size(221, 21);
            this.txtoldusual.TabIndex = 35;
            this.txtoldusual.TextChanged += new System.EventHandler(this.txtoldusual_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(337, 436);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 16);
            this.label8.TabIndex = 34;
            this.label8.Text = "旧平时成绩：";
            // 
            // btnoldlast
            // 
            this.btnoldlast.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnoldlast.Location = new System.Drawing.Point(683, 500);
            this.btnoldlast.Name = "btnoldlast";
            this.btnoldlast.Size = new System.Drawing.Size(124, 45);
            this.btnoldlast.TabIndex = 39;
            this.btnoldlast.Text = "录入末考成绩";
            this.btnoldlast.UseVisualStyleBackColor = true;
            this.btnoldlast.Click += new System.EventHandler(this.btnoldlast_Click);
            // 
            // txtoldlast
            // 
            this.txtoldlast.Location = new System.Drawing.Point(446, 514);
            this.txtoldlast.Name = "txtoldlast";
            this.txtoldlast.Size = new System.Drawing.Size(221, 21);
            this.txtoldlast.TabIndex = 38;
            this.txtoldlast.TextChanged += new System.EventHandler(this.txtoldlast_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(337, 514);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 16);
            this.label9.TabIndex = 37;
            this.label9.Text = "旧末考成绩：";
            // 
            // admalter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 579);
            this.Controls.Add(this.btnoldlast);
            this.Controls.Add(this.txtoldlast);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnoldusual);
            this.Controls.Add(this.txtoldusual);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnnewlast);
            this.Controls.Add(this.txtnewlast);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnnewusual);
            this.Controls.Add(this.txtnewusual);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btncertain);
            this.Controls.Add(this.txttime);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtview);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txtcno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsno);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label7);
            this.Name = "admalter";
            this.Text = "修改成绩";
            this.Load += new System.EventHandler(this.admalter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.成绩表BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.课程表BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.选课表BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private XSCJGL1DataSet xSCJGL1DataSet;
        private System.Windows.Forms.BindingSource 成绩表BindingSource;
        private XSCJGL1DataSetTableAdapters.成绩表TableAdapter 成绩表TableAdapter;
        private System.Windows.Forms.BindingSource 课程表BindingSource;
        private XSCJGL1DataSetTableAdapters.课程表TableAdapter 课程表TableAdapter;
        private System.Windows.Forms.BindingSource 选课表BindingSource;
        private XSCJGL1DataSetTableAdapters.选课表TableAdapter 选课表TableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn 学号DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 学生姓名DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 课程号DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 课程名称DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 教师姓名DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 平时成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 末考成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 综合成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 是否修改成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 意见DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 原平时成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 原末考成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 修改时间DataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtsno;
        private System.Windows.Forms.TextBox txtcno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btncertain;
        private System.Windows.Forms.TextBox txttime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtview;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtnewusual;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnnewusual;
        private System.Windows.Forms.Button btnnewlast;
        private System.Windows.Forms.TextBox txtnewlast;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnoldusual;
        private System.Windows.Forms.TextBox txtoldusual;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnoldlast;
        private System.Windows.Forms.TextBox txtoldlast;
        private System.Windows.Forms.Label label9;
    }
}