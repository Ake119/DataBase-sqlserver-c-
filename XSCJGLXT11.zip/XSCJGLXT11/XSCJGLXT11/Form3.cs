﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class Form3 : Form
    {
        private string connectionString = "Data Source=. ; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";
        public Form3()
        {
            InitializeComponent();
        }

        private void txtano_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtapwd_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string adminId = txtano.Text.Trim();
            string password = txtapwd.Text.Trim();

            // 输入验证
            if (string.IsNullOrEmpty(adminId) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("请输入管理员号和密码！");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT * FROM 管理员信息表 WHERE 管理员号=@AdminId AND 密码=@Password";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@AdminId", adminId);
                    command.Parameters.AddWithValue("@Password", password);

                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        MessageBox.Show("登录成功！");

                       
                        AdmMain adminMain = new AdmMain();
                        adminMain.FormClosed += (s, args) => this.Show();  // 管理员主窗体关闭时显示登录窗体
                        adminMain.Show();
                       
                    }
                    else
                    {
                        MessageBox.Show("管理员号或密码错误，登录失败！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("登录失败: " + ex.Message);
                }
            }
        }
    }
}
