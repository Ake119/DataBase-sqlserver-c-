﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void txtsno_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtspwd_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string studentId = this.txtsno.Text;    
            string password = this.txtspwd.Text;     
            string connectionString = "Data Source=.; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT * FROM 学生信息表 WHERE 学号=@StudentId AND 密码=@Password";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@StudentId", studentId);
                    command.Parameters.AddWithValue("@Password", password);
                    command.CommandType = CommandType.Text;

                    SqlDataReader sdr = command.ExecuteReader();
                    if (sdr.Read())
                    {
                        MessageBox.Show("登录成功");
                        string studentName = sdr["学生姓名"].ToString();
                        StudentMain studentMain = new StudentMain(studentId, studentName);
                        studentMain.Show();
                        //this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("用户名或密码错误, 登录失败");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("错误: " + ex.Message);
                }
            }
        }
    }
}
