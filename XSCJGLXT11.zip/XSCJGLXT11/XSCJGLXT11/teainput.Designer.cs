﻿namespace XSCJGLXT11
{
    partial class teainput
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.xSCJGL1DataSet = new XSCJGLXT11.XSCJGL1DataSet();
            this.成绩表BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.成绩表TableAdapter = new XSCJGLXT11.XSCJGL1DataSetTableAdapters.成绩表TableAdapter();
            this.学号DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.课程号DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.课程名称DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.平时成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.末考成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.综合成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.btnlast = new System.Windows.Forms.Button();
            this.txtlast = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnusual = new System.Windows.Forms.Button();
            this.txtusual = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.txtcno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtsno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.成绩表BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.学号DataGridViewTextBoxColumn,
            this.课程号DataGridViewTextBoxColumn,
            this.课程名称DataGridViewTextBoxColumn,
            this.平时成绩DataGridViewTextBoxColumn,
            this.末考成绩DataGridViewTextBoxColumn,
            this.综合成绩DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.成绩表BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(29, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(644, 181);
            this.dataGridView1.TabIndex = 0;
            // 
            // xSCJGL1DataSet
            // 
            this.xSCJGL1DataSet.DataSetName = "XSCJGL1DataSet";
            this.xSCJGL1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 成绩表BindingSource
            // 
            this.成绩表BindingSource.DataMember = "成绩表";
            this.成绩表BindingSource.DataSource = this.xSCJGL1DataSet;
            // 
            // 成绩表TableAdapter
            // 
            this.成绩表TableAdapter.ClearBeforeFill = true;
            // 
            // 学号DataGridViewTextBoxColumn
            // 
            this.学号DataGridViewTextBoxColumn.DataPropertyName = "学号";
            this.学号DataGridViewTextBoxColumn.HeaderText = "学号";
            this.学号DataGridViewTextBoxColumn.Name = "学号DataGridViewTextBoxColumn";
            // 
            // 课程号DataGridViewTextBoxColumn
            // 
            this.课程号DataGridViewTextBoxColumn.DataPropertyName = "课程号";
            this.课程号DataGridViewTextBoxColumn.HeaderText = "课程号";
            this.课程号DataGridViewTextBoxColumn.Name = "课程号DataGridViewTextBoxColumn";
            // 
            // 课程名称DataGridViewTextBoxColumn
            // 
            this.课程名称DataGridViewTextBoxColumn.DataPropertyName = "课程名称";
            this.课程名称DataGridViewTextBoxColumn.HeaderText = "课程名称";
            this.课程名称DataGridViewTextBoxColumn.Name = "课程名称DataGridViewTextBoxColumn";
            // 
            // 平时成绩DataGridViewTextBoxColumn
            // 
            this.平时成绩DataGridViewTextBoxColumn.DataPropertyName = "平时成绩";
            this.平时成绩DataGridViewTextBoxColumn.HeaderText = "平时成绩";
            this.平时成绩DataGridViewTextBoxColumn.Name = "平时成绩DataGridViewTextBoxColumn";
            // 
            // 末考成绩DataGridViewTextBoxColumn
            // 
            this.末考成绩DataGridViewTextBoxColumn.DataPropertyName = "末考成绩";
            this.末考成绩DataGridViewTextBoxColumn.HeaderText = "末考成绩";
            this.末考成绩DataGridViewTextBoxColumn.Name = "末考成绩DataGridViewTextBoxColumn";
            // 
            // 综合成绩DataGridViewTextBoxColumn
            // 
            this.综合成绩DataGridViewTextBoxColumn.DataPropertyName = "综合成绩";
            this.综合成绩DataGridViewTextBoxColumn.HeaderText = "综合成绩";
            this.综合成绩DataGridViewTextBoxColumn.Name = "综合成绩DataGridViewTextBoxColumn";
            this.综合成绩DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("黑体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(25, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 24);
            this.label7.TabIndex = 17;
            this.label7.Text = "录入成绩";
            // 
            // btnlast
            // 
            this.btnlast.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnlast.Location = new System.Drawing.Point(549, 348);
            this.btnlast.Name = "btnlast";
            this.btnlast.Size = new System.Drawing.Size(124, 45);
            this.btnlast.TabIndex = 44;
            this.btnlast.Text = "录入末考成绩";
            this.btnlast.UseVisualStyleBackColor = true;
            this.btnlast.Click += new System.EventHandler(this.btnlast_Click);
            // 
            // txtlast
            // 
            this.txtlast.Location = new System.Drawing.Point(358, 363);
            this.txtlast.Name = "txtlast";
            this.txtlast.Size = new System.Drawing.Size(151, 21);
            this.txtlast.TabIndex = 43;
            this.txtlast.TextChanged += new System.EventHandler(this.txtlast_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(249, 363);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 16);
            this.label6.TabIndex = 42;
            this.label6.Text = "末考成绩：";
            // 
            // btnusual
            // 
            this.btnusual.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnusual.Location = new System.Drawing.Point(549, 257);
            this.btnusual.Name = "btnusual";
            this.btnusual.Size = new System.Drawing.Size(124, 45);
            this.btnusual.TabIndex = 41;
            this.btnusual.Text = "录入平时成绩";
            this.btnusual.UseVisualStyleBackColor = true;
            this.btnusual.Click += new System.EventHandler(this.btnusual_Click);
            // 
            // txtusual
            // 
            this.txtusual.Location = new System.Drawing.Point(358, 271);
            this.txtusual.Name = "txtusual";
            this.txtusual.Size = new System.Drawing.Size(151, 21);
            this.txtusual.TabIndex = 40;
            this.txtusual.TextChanged += new System.EventHandler(this.txtusual_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(249, 271);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 16);
            this.label5.TabIndex = 39;
            this.label5.Text = "平时成绩：";
            // 
            // btnsearch
            // 
            this.btnsearch.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnsearch.Location = new System.Drawing.Point(84, 374);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(140, 40);
            this.btnsearch.TabIndex = 38;
            this.btnsearch.Text = "查询";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txtcno
            // 
            this.txtcno.Location = new System.Drawing.Point(84, 322);
            this.txtcno.Name = "txtcno";
            this.txtcno.Size = new System.Drawing.Size(141, 21);
            this.txtcno.TabIndex = 37;
            this.txtcno.TextChanged += new System.EventHandler(this.txtcno_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(7, 322);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 36;
            this.label2.Text = "课程号：";
            // 
            // txtsno
            // 
            this.txtsno.Location = new System.Drawing.Point(83, 270);
            this.txtsno.Name = "txtsno";
            this.txtsno.Size = new System.Drawing.Size(141, 21);
            this.txtsno.TabIndex = 35;
            this.txtsno.TextChanged += new System.EventHandler(this.txtsno_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(22, 270);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 34;
            this.label1.Text = "学号：";
            // 
            // teainput
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 450);
            this.Controls.Add(this.btnlast);
            this.Controls.Add(this.txtlast);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnusual);
            this.Controls.Add(this.txtusual);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txtcno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsno);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dataGridView1);
            this.Name = "teainput";
            this.Text = "录入成绩";
            this.Load += new System.EventHandler(this.teainput_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.成绩表BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private XSCJGL1DataSet xSCJGL1DataSet;
        private System.Windows.Forms.BindingSource 成绩表BindingSource;
        private XSCJGL1DataSetTableAdapters.成绩表TableAdapter 成绩表TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn 学号DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 课程号DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 课程名称DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 平时成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 末考成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 综合成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnlast;
        private System.Windows.Forms.TextBox txtlast;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnusual;
        private System.Windows.Forms.TextBox txtusual;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox txtcno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtsno;
        private System.Windows.Forms.Label label1;
    }
}