﻿namespace XSCJGLXT11
{
    partial class stuselect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.课程号DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.课程名称DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.教师姓名DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.选课表BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.xSCJGL1DataSet = new XSCJGLXT11.XSCJGL1DataSet();
            this.选课表BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.选课表TableAdapter = new XSCJGLXT11.XSCJGL1DataSetTableAdapters.选课表TableAdapter();
            this.btnadd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtcnoadd = new System.Windows.Forms.TextBox();
            this.txtcnodelete = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btndelete = new System.Windows.Forms.Button();
            this.课程表BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.课程表TableAdapter = new XSCJGLXT11.XSCJGL1DataSetTableAdapters.课程表TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.选课表BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.选课表BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.课程表BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.课程号DataGridViewTextBoxColumn,
            this.课程名称DataGridViewTextBoxColumn,
            this.教师姓名DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.课程表BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(16, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(343, 173);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // 课程号DataGridViewTextBoxColumn
            // 
            this.课程号DataGridViewTextBoxColumn.DataPropertyName = "课程号";
            this.课程号DataGridViewTextBoxColumn.HeaderText = "课程号";
            this.课程号DataGridViewTextBoxColumn.Name = "课程号DataGridViewTextBoxColumn";
            // 
            // 课程名称DataGridViewTextBoxColumn
            // 
            this.课程名称DataGridViewTextBoxColumn.DataPropertyName = "课程名称";
            this.课程名称DataGridViewTextBoxColumn.HeaderText = "课程名称";
            this.课程名称DataGridViewTextBoxColumn.Name = "课程名称DataGridViewTextBoxColumn";
            // 
            // 教师姓名DataGridViewTextBoxColumn
            // 
            this.教师姓名DataGridViewTextBoxColumn.DataPropertyName = "教师姓名";
            this.教师姓名DataGridViewTextBoxColumn.HeaderText = "教师姓名";
            this.教师姓名DataGridViewTextBoxColumn.Name = "教师姓名DataGridViewTextBoxColumn";
            // 
            // 选课表BindingSource1
            // 
            this.选课表BindingSource1.DataMember = "选课表";
            this.选课表BindingSource1.DataSource = this.xSCJGL1DataSet;
            // 
            // xSCJGL1DataSet
            // 
            this.xSCJGL1DataSet.DataSetName = "XSCJGL1DataSet";
            this.xSCJGL1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 选课表BindingSource
            // 
            this.选课表BindingSource.DataMember = "选课表";
            this.选课表BindingSource.DataSource = this.xSCJGL1DataSet;
            // 
            // 选课表TableAdapter
            // 
            this.选课表TableAdapter.ClearBeforeFill = true;
            // 
            // btnadd
            // 
            this.btnadd.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnadd.Location = new System.Drawing.Point(233, 263);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(125, 42);
            this.btnadd.TabIndex = 1;
            this.btnadd.Text = "确认添加";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(13, 236);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "请输入课程号选课：";
            // 
            // txtcnoadd
            // 
            this.txtcnoadd.Location = new System.Drawing.Point(16, 275);
            this.txtcnoadd.Name = "txtcnoadd";
            this.txtcnoadd.Size = new System.Drawing.Size(175, 21);
            this.txtcnoadd.TabIndex = 3;
            this.txtcnoadd.TextChanged += new System.EventHandler(this.txtcnoadd_TextChanged);
            // 
            // txtcnodelete
            // 
            this.txtcnodelete.Location = new System.Drawing.Point(16, 373);
            this.txtcnodelete.Name = "txtcnodelete";
            this.txtcnodelete.Size = new System.Drawing.Size(175, 21);
            this.txtcnodelete.TabIndex = 6;
            this.txtcnodelete.TextChanged += new System.EventHandler(this.txtcnodelete_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(13, 334);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "请输入课程号退选：";
            // 
            // btndelete
            // 
            this.btndelete.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btndelete.Location = new System.Drawing.Point(233, 361);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(125, 42);
            this.btndelete.TabIndex = 4;
            this.btndelete.Text = "确认退选";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // 课程表BindingSource
            // 
            this.课程表BindingSource.DataMember = "课程表";
            this.课程表BindingSource.DataSource = this.xSCJGL1DataSet;
            // 
            // 课程表TableAdapter
            // 
            this.课程表TableAdapter.ClearBeforeFill = true;
            // 
            // stuselect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 450);
            this.Controls.Add(this.txtcnodelete);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.txtcnoadd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.dataGridView1);
            this.Name = "stuselect";
            this.Text = "学生选课";
            this.Load += new System.EventHandler(this.stuselect_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.选课表BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.选课表BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.课程表BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private XSCJGL1DataSet xSCJGL1DataSet;
        private System.Windows.Forms.BindingSource 选课表BindingSource;
        private XSCJGL1DataSetTableAdapters.选课表TableAdapter 选课表TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn 课程号DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 课程名称DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 教师姓名DataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource 选课表BindingSource1;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtcnoadd;
        private System.Windows.Forms.TextBox txtcnodelete;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.BindingSource 课程表BindingSource;
        private XSCJGL1DataSetTableAdapters.课程表TableAdapter 课程表TableAdapter;
    }
}