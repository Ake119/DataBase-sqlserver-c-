﻿namespace XSCJGLXT11
{
    partial class teaalter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnalter = new System.Windows.Forms.Button();
            this.txtnew = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtold = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txttno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnalter
            // 
            this.btnalter.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnalter.Location = new System.Drawing.Point(24, 333);
            this.btnalter.Name = "btnalter";
            this.btnalter.Size = new System.Drawing.Size(336, 66);
            this.btnalter.TabIndex = 13;
            this.btnalter.Text = "确认修改";
            this.btnalter.UseVisualStyleBackColor = true;
            this.btnalter.Click += new System.EventHandler(this.btnalter_Click);
            // 
            // txtnew
            // 
            this.txtnew.Location = new System.Drawing.Point(24, 255);
            this.txtnew.Name = "txtnew";
            this.txtnew.Size = new System.Drawing.Size(336, 21);
            this.txtnew.TabIndex = 12;
            this.txtnew.TextChanged += new System.EventHandler(this.txtnew_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(21, 220);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "请输入新密码：";
            // 
            // txtold
            // 
            this.txtold.Location = new System.Drawing.Point(24, 167);
            this.txtold.Name = "txtold";
            this.txtold.Size = new System.Drawing.Size(336, 21);
            this.txtold.TabIndex = 10;
            this.txtold.TextChanged += new System.EventHandler(this.txtold_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(21, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "请输入旧密码：";
            // 
            // txttno
            // 
            this.txttno.Location = new System.Drawing.Point(24, 79);
            this.txttno.Name = "txttno";
            this.txttno.Size = new System.Drawing.Size(336, 21);
            this.txttno.TabIndex = 8;
            this.txttno.TextChanged += new System.EventHandler(this.txttno_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(21, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "请输入教师号：";
            // 
            // teaalter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 468);
            this.Controls.Add(this.btnalter);
            this.Controls.Add(this.txtnew);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtold);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txttno);
            this.Controls.Add(this.label1);
            this.Name = "teaalter";
            this.Text = "修改密码";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnalter;
        private System.Windows.Forms.TextBox txtnew;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtold;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txttno;
        private System.Windows.Forms.Label label1;
    }
}