﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class admmanage : Form
    {
        private string connectionString = "Data Source=. ; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";

        public admmanage()
        {
            InitializeComponent();
        }

        private void admmanage_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“xSCJGL1DataSet.学生信息表”中。您可以根据需要移动或移除它。
            this.学生信息表TableAdapter.Fill(this.xSCJGL1DataSet.学生信息表);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            string studentId = textBox1.Text.Trim();
            if (string.IsNullOrEmpty(studentId))
            {
                MessageBox.Show("请输入学号！");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string updateQuery = "UPDATE 学生信息表 SET 密码='123456' WHERE 学号=@StudentId";
                    SqlCommand cmd = new SqlCommand(updateQuery, conn);
                    cmd.Parameters.AddWithValue("@StudentId", studentId);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("密码重置成功！");
                        RefreshDataGridView();
                    }
                    else
                    {
                        MessageBox.Show("未找到该学号！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("密码重置失败: " + ex.Message);
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            string studentId = textBox1.Text.Trim();
            string studentName = textBox2.Text.Trim();
            string gender = textBox3.Text.Trim();
            string birthDate = textBox4.Text.Trim();
            string majorId = textBox5.Text.Trim();

            if (string.IsNullOrEmpty(studentId) || string.IsNullOrEmpty(studentName) ||
                string.IsNullOrEmpty(gender) || string.IsNullOrEmpty(birthDate) ||
                string.IsNullOrEmpty(majorId))
            {
                MessageBox.Show("请填写完整信息！");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string insertQuery = @"INSERT INTO 学生信息表 
                                    (学号, 学生姓名, 性别, 出生日期, 专业代号, 密码) 
                                    VALUES 
                                    (@StudentId, @StudentName, @Gender, @BirthDate, @MajorId, '123456')";

                    SqlCommand cmd = new SqlCommand(insertQuery, conn);
                    cmd.Parameters.AddWithValue("@StudentId", studentId);
                    cmd.Parameters.AddWithValue("@StudentName", studentName);
                    cmd.Parameters.AddWithValue("@Gender", gender);
                    cmd.Parameters.AddWithValue("@BirthDate", birthDate);
                    cmd.Parameters.AddWithValue("@MajorId", majorId);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("添加学生信息成功！");
                        RefreshDataGridView();
                        // 清空输入框
                        textBox1.Clear();
                        textBox2.Clear();
                        textBox3.Clear();
                        textBox4.Clear();
                        textBox5.Clear();
                    }
                    else
                    {
                        MessageBox.Show("添加学生信息失败！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("添加学生信息失败: " + ex.Message);
                }
            }
        }
        private void RefreshDataGridView()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM 学生信息表";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("刷新数据失败: " + ex.Message);
                }
            }
        }
    }
}
