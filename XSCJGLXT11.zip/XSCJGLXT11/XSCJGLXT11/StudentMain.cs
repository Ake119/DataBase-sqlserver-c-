﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class StudentMain : Form
    {
        private string studentId;
        private string studentName;
        public StudentMain(string studentId, string studentName)
        {
            InitializeComponent();
            this.studentId = studentId;
            this.studentName = studentName;
        }

        private void lblWelcom_Click(object sender, EventArgs e)
        {
            lblWelcome.Text = $"欢迎您，{studentName} 同学！";
        }

        private void btnquery_Click(object sender, EventArgs e)
        {
            stuquery stuq = new stuquery();
            stuq.ShowDialog();
            this.Hide();
        }

        private void btnselect_Click(object sender, EventArgs e)
        {
            stuselect stus = new stuselect(studentId, studentName);
            stus.ShowDialog();
            this.Hide();
        }

        private void btnalter_Click(object sender, EventArgs e)
        {
            stualter stua = new stualter();
            stua.FormClosed += (s, args) => this.Show();  // 当密码修改窗体关闭时显示主窗体
            stua.ShowDialog();
            this.Hide();
        }
    }
}
