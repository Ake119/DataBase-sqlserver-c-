﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class TeaMain : Form
    {
        private string connectionString = "Data Source=. ; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";
        private string _teacherId;    // 改名避免命名冲突
        private string _teacherName;
        public TeaMain(string teacherId, string teacherName)
        {
            InitializeComponent();
            _teacherId = teacherId;
            _teacherName = teacherName;
            lblWelcome.Text = $"欢迎您，{_teacherName} 老师！";
        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {

        }

        private void btninput_Click(object sender, EventArgs e)
        {
            
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT 录入成绩开关 FROM 录入成绩";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    bool isInputEnabled = Convert.ToBoolean(cmd.ExecuteScalar());

                    if (!isInputEnabled)
                    {
                        MessageBox.Show("当前不允许录入成绩！");
                        return;
                    }
                    teainput input = new teainput();
                    input.SetTeacherInfo(_teacherId, _teacherName);
                    input.FormClosed += (s, args) => this.Show();
                    input.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("错误: " + ex.Message);
                }
            }
        }

        private void btnalter_Click(object sender, EventArgs e)
        {
            teaalter alter = new teaalter(); 
            alter.SetTeacherInfo(_teacherId, _teacherName);  
            alter.FormClosed += (s, args) => this.Show();
            alter.Show();
            this.Hide();
        }
    }
}
