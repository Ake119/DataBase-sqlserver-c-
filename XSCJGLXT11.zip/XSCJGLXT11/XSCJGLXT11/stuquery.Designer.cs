﻿namespace XSCJGLXT11
{
    partial class stuquery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.xSCJGL1DataSet = new XSCJGLXT11.XSCJGL1DataSet();
            this.xSCJGL1DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnlogin = new System.Windows.Forms.Button();
            this.txtsno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtspwd = new System.Windows.Forms.TextBox();
            this.成绩表BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.成绩表TableAdapter = new XSCJGLXT11.XSCJGL1DataSetTableAdapters.成绩表TableAdapter();
            this.学号DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.课程号DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.课程名称DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.平时成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.末考成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.综合成绩DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.成绩表BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.学号DataGridViewTextBoxColumn,
            this.课程号DataGridViewTextBoxColumn,
            this.课程名称DataGridViewTextBoxColumn,
            this.平时成绩DataGridViewTextBoxColumn,
            this.末考成绩DataGridViewTextBoxColumn,
            this.综合成绩DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.成绩表BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(80, 36);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(643, 194);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // xSCJGL1DataSet
            // 
            this.xSCJGL1DataSet.DataSetName = "XSCJGL1DataSet";
            this.xSCJGL1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // xSCJGL1DataSetBindingSource
            // 
            this.xSCJGL1DataSetBindingSource.DataSource = this.xSCJGL1DataSet;
            this.xSCJGL1DataSetBindingSource.Position = 0;
            // 
            // btnlogin
            // 
            this.btnlogin.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnlogin.Location = new System.Drawing.Point(459, 300);
            this.btnlogin.Name = "btnlogin";
            this.btnlogin.Size = new System.Drawing.Size(307, 100);
            this.btnlogin.TabIndex = 1;
            this.btnlogin.Text = "登录";
            this.btnlogin.UseVisualStyleBackColor = true;
            this.btnlogin.Click += new System.EventHandler(this.btnlogin_Click);
            // 
            // txtsno
            // 
            this.txtsno.Location = new System.Drawing.Point(12, 300);
            this.txtsno.Name = "txtsno";
            this.txtsno.Size = new System.Drawing.Size(414, 21);
            this.txtsno.TabIndex = 2;
            this.txtsno.TextChanged += new System.EventHandler(this.txtsno_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(12, 272);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "请输入学生号：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(15, 351);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "请输入密码：";
            // 
            // txtspwd
            // 
            this.txtspwd.Location = new System.Drawing.Point(15, 379);
            this.txtspwd.Name = "txtspwd";
            this.txtspwd.Size = new System.Drawing.Size(414, 21);
            this.txtspwd.TabIndex = 4;
            this.txtspwd.TextChanged += new System.EventHandler(this.txtspwd_TextChanged);
            // 
            // 成绩表BindingSource
            // 
            this.成绩表BindingSource.DataMember = "成绩表";
            this.成绩表BindingSource.DataSource = this.xSCJGL1DataSet;
            // 
            // 成绩表TableAdapter
            // 
            this.成绩表TableAdapter.ClearBeforeFill = true;
            // 
            // 学号DataGridViewTextBoxColumn
            // 
            this.学号DataGridViewTextBoxColumn.DataPropertyName = "学号";
            this.学号DataGridViewTextBoxColumn.HeaderText = "学号";
            this.学号DataGridViewTextBoxColumn.Name = "学号DataGridViewTextBoxColumn";
            // 
            // 课程号DataGridViewTextBoxColumn
            // 
            this.课程号DataGridViewTextBoxColumn.DataPropertyName = "课程号";
            this.课程号DataGridViewTextBoxColumn.HeaderText = "课程号";
            this.课程号DataGridViewTextBoxColumn.Name = "课程号DataGridViewTextBoxColumn";
            // 
            // 课程名称DataGridViewTextBoxColumn
            // 
            this.课程名称DataGridViewTextBoxColumn.DataPropertyName = "课程名称";
            this.课程名称DataGridViewTextBoxColumn.HeaderText = "课程名称";
            this.课程名称DataGridViewTextBoxColumn.Name = "课程名称DataGridViewTextBoxColumn";
            // 
            // 平时成绩DataGridViewTextBoxColumn
            // 
            this.平时成绩DataGridViewTextBoxColumn.DataPropertyName = "平时成绩";
            this.平时成绩DataGridViewTextBoxColumn.HeaderText = "平时成绩";
            this.平时成绩DataGridViewTextBoxColumn.Name = "平时成绩DataGridViewTextBoxColumn";
            // 
            // 末考成绩DataGridViewTextBoxColumn
            // 
            this.末考成绩DataGridViewTextBoxColumn.DataPropertyName = "末考成绩";
            this.末考成绩DataGridViewTextBoxColumn.HeaderText = "末考成绩";
            this.末考成绩DataGridViewTextBoxColumn.Name = "末考成绩DataGridViewTextBoxColumn";
            // 
            // 综合成绩DataGridViewTextBoxColumn
            // 
            this.综合成绩DataGridViewTextBoxColumn.DataPropertyName = "综合成绩";
            this.综合成绩DataGridViewTextBoxColumn.HeaderText = "综合成绩";
            this.综合成绩DataGridViewTextBoxColumn.Name = "综合成绩DataGridViewTextBoxColumn";
            this.综合成绩DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // stuquery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtspwd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtsno);
            this.Controls.Add(this.btnlogin);
            this.Controls.Add(this.dataGridView1);
            this.Name = "stuquery";
            this.Text = "查询成绩";
            this.Load += new System.EventHandler(this.stuquery_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xSCJGL1DataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.成绩表BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource xSCJGL1DataSetBindingSource;
        private XSCJGL1DataSet xSCJGL1DataSet;
        private System.Windows.Forms.Button btnlogin;
        private System.Windows.Forms.TextBox txtsno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtspwd;
        private System.Windows.Forms.BindingSource 成绩表BindingSource;
        private XSCJGL1DataSetTableAdapters.成绩表TableAdapter 成绩表TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn 学号DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 课程号DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 课程名称DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 平时成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 末考成绩DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 综合成绩DataGridViewTextBoxColumn;
    }
}