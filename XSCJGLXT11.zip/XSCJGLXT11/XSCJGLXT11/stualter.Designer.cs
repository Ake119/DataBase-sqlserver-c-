﻿namespace XSCJGLXT11
{
    partial class stualter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtsno = new System.Windows.Forms.TextBox();
            this.txtold = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtnew = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnalter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(21, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "请输入学号：";
            // 
            // txtsno
            // 
            this.txtsno.Location = new System.Drawing.Point(24, 80);
            this.txtsno.Name = "txtsno";
            this.txtsno.Size = new System.Drawing.Size(336, 21);
            this.txtsno.TabIndex = 1;
            this.txtsno.TextChanged += new System.EventHandler(this.txtsno_TextChanged);
            // 
            // txtold
            // 
            this.txtold.Location = new System.Drawing.Point(24, 168);
            this.txtold.Name = "txtold";
            this.txtold.Size = new System.Drawing.Size(336, 21);
            this.txtold.TabIndex = 3;
            this.txtold.TextChanged += new System.EventHandler(this.txtold_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(21, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "请输入旧密码：";
            // 
            // txtnew
            // 
            this.txtnew.Location = new System.Drawing.Point(24, 256);
            this.txtnew.Name = "txtnew";
            this.txtnew.Size = new System.Drawing.Size(336, 21);
            this.txtnew.TabIndex = 5;
            this.txtnew.TextChanged += new System.EventHandler(this.txtnew_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(21, 221);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "请输入新密码：";
            // 
            // btnalter
            // 
            this.btnalter.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnalter.Location = new System.Drawing.Point(24, 334);
            this.btnalter.Name = "btnalter";
            this.btnalter.Size = new System.Drawing.Size(336, 66);
            this.btnalter.TabIndex = 6;
            this.btnalter.Text = "确认修改";
            this.btnalter.UseVisualStyleBackColor = true;
            this.btnalter.Click += new System.EventHandler(this.btnalter_Click);
            // 
            // stualter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 468);
            this.Controls.Add(this.btnalter);
            this.Controls.Add(this.txtnew);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtold);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsno);
            this.Controls.Add(this.label1);
            this.Name = "stualter";
            this.Text = "修改密码";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtsno;
        private System.Windows.Forms.TextBox txtold;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtnew;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnalter;
    }
}