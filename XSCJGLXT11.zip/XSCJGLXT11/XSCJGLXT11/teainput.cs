﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class teainput : Form
    {
        private string connectionString = "Data Source=. ; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";
        private string teacherId;
        private string teacherName;

        public teainput()
        {
            InitializeComponent();
            dataGridView1.Visible = false;
        }
        public void SetTeacherInfo(string id, string name)
        {
            teacherId = id;
            teacherName = name;
        }

        private void teainput_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“xSCJGL1DataSet.成绩表”中。您可以根据需要移动或移除它。
            this.成绩表TableAdapter.Fill(this.xSCJGL1DataSet.成绩表);

        }

        private void txtsno_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcno_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            string studentId = txtsno.Text.Trim();
            string courseId = txtcno.Text.Trim();

            if (string.IsNullOrEmpty(studentId) || string.IsNullOrEmpty(courseId))
            {
                MessageBox.Show("请输入学号和课程号！");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM 选课表 WHERE 学号=@StudentId AND 课程号=@CourseId";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@StudentId", studentId);
                    cmd.Parameters.AddWithValue("@CourseId", courseId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = dt;
                        dataGridView1.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("未找到相关记录！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("查询失败: " + ex.Message);
                }
            }
        }

        private void txtusual_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtlast_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnusual_Click(object sender, EventArgs e)
        {
            UpdateGrade("平时成绩", txtusual.Text.Trim());
        }

        private void btnlast_Click(object sender, EventArgs e)
        {
            UpdateGrade("平时成绩", txtusual.Text.Trim());
        }
        private void UpdateGrade(string gradeType, string gradeValue)
        {
            string studentId = txtsno.Text.Trim();
            string courseId = txtcno.Text.Trim();

            if (string.IsNullOrEmpty(gradeValue))
            {
                MessageBox.Show("请输入成绩！");
                return;
            }

           
            if (!float.TryParse(gradeValue, out float score) || score < 0 || score > 100)
            {
                MessageBox.Show("请输入0-100之间的有效成绩！");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string updateQuery = $"UPDATE 选课表 SET {gradeType}=@Grade WHERE 学号=@StudentId AND 课程号=@CourseId";
                    SqlCommand cmd = new SqlCommand(updateQuery, conn);
                    cmd.Parameters.AddWithValue("@Grade", gradeValue);
                    cmd.Parameters.AddWithValue("@StudentId", studentId);
                    cmd.Parameters.AddWithValue("@CourseId", courseId);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("成绩录入成功！");
                        btnsearch_Click(null, null);  // 刷新显示
                    }
                    else
                    {
                        MessageBox.Show("成绩录入失败！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("成绩录入失败: " + ex.Message);
                }
            }
        }
    }
}
