﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class teaalter : Form
    {
        private string connectionString = "Data Source=. ; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";
        private string teacherId;
        private string teacherName;
        public teaalter()
        {
            InitializeComponent();
        }
        public void SetTeacherInfo(string id, string name)
        {
            teacherId = id;
            teacherName = name;
            txttno.Text = teacherId;  // 自动填充教师号
            txttno.ReadOnly = true;   // 设置为只读
        }

        private void txttno_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtold_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtnew_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnalter_Click(object sender, EventArgs e)
        {
            string teacherId = txttno.Text.Trim();
            string oldPassword = txtold.Text.Trim();
            string newPassword = txtnew.Text.Trim();

            // 输入验证
            if (string.IsNullOrEmpty(teacherId) || string.IsNullOrEmpty(oldPassword) || string.IsNullOrEmpty(newPassword))
            {
                MessageBox.Show("请填写完整信息！");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    // 首先验证教师号和旧密码是否匹配
                    string checkQuery = "SELECT COUNT(*) FROM 教师信息表 WHERE 教师号=@TeacherId AND 密码=@OldPassword";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                    checkCmd.Parameters.AddWithValue("@TeacherId", teacherId);
                    checkCmd.Parameters.AddWithValue("@OldPassword", oldPassword);

                    int exists = (int)checkCmd.ExecuteScalar();
                    if (exists > 0)
                    {
                        // 密码匹配，执行更新
                        string updateQuery = "UPDATE 教师信息表 SET 密码=@NewPassword WHERE 教师号=@TeacherId";
                        SqlCommand updateCmd = new SqlCommand(updateQuery, conn);
                        updateCmd.Parameters.AddWithValue("@NewPassword", newPassword);
                        updateCmd.Parameters.AddWithValue("@TeacherId", teacherId);

                        int result = updateCmd.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("密码修改成功！");
                            // 清空输入框
                            txtold.Clear();
                            txtnew.Clear();
                        }
                        else
                        {
                            MessageBox.Show("密码修改失败！");
                        }
                    }
                    else
                    {
                        MessageBox.Show("教师号或原密码错误！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("错误: " + ex.Message);
                }
            }
        }
    }
}
