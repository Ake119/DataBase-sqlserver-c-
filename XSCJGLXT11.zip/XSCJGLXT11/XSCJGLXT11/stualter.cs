﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class stualter : Form
    {
        private string connectionString = "Data Source=. ; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";
        public stualter()
        {
            InitializeComponent();
        }

        private void txtsno_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtold_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtnew_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnalter_Click(object sender, EventArgs e)
        {
            string studentId = txtsno.Text.Trim();
            string oldPassword = txtold.Text.Trim();
            string newPassword = txtnew.Text.Trim();

            // 输入验证
            if (string.IsNullOrEmpty(studentId) || string.IsNullOrEmpty(oldPassword) || string.IsNullOrEmpty(newPassword))
            {
                MessageBox.Show("请填写完整信息！");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                   
                    string checkQuery = "SELECT COUNT(*) FROM 学生信息表 WHERE 学号=@StudentId AND 密码=@OldPassword";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                    checkCmd.Parameters.AddWithValue("@StudentId", studentId);
                    checkCmd.Parameters.AddWithValue("@OldPassword", oldPassword);

                    int exists = (int)checkCmd.ExecuteScalar();
                    if (exists > 0)
                    {
                        // 密码匹配
                        string updateQuery = "UPDATE 学生信息表 SET 密码=@NewPassword WHERE 学号=@StudentId";
                        SqlCommand updateCmd = new SqlCommand(updateQuery, conn);
                        updateCmd.Parameters.AddWithValue("@NewPassword", newPassword);
                        updateCmd.Parameters.AddWithValue("@StudentId", studentId);

                        int result = updateCmd.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("密码修改成功！");
                            txtsno.Clear();
                            txtold.Clear();
                            txtnew.Clear();
                        }
                        else
                        {
                            MessageBox.Show("密码修改失败！");
                        }
                    }
                    else
                    {
                        MessageBox.Show("学号或原密码错误！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("错误: " + ex.Message);
                }
            }
        }
    }
}
