﻿namespace XSCJGLXT11
{
    partial class StudentMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnalter = new System.Windows.Forms.Button();
            this.btnselect = new System.Windows.Forms.Button();
            this.btnquery = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("黑体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWelcome.Location = new System.Drawing.Point(30, 50);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(82, 24);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "欢迎您";
            this.lblWelcome.Click += new System.EventHandler(this.lblWelcom_Click);
            // 
            // btnalter
            // 
            this.btnalter.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnalter.Location = new System.Drawing.Point(560, 153);
            this.btnalter.Name = "btnalter";
            this.btnalter.Size = new System.Drawing.Size(195, 73);
            this.btnalter.TabIndex = 5;
            this.btnalter.Text = "修改密码";
            this.btnalter.UseVisualStyleBackColor = true;
            this.btnalter.Click += new System.EventHandler(this.btnalter_Click);
            // 
            // btnselect
            // 
            this.btnselect.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnselect.Location = new System.Drawing.Point(294, 153);
            this.btnselect.Name = "btnselect";
            this.btnselect.Size = new System.Drawing.Size(195, 73);
            this.btnselect.TabIndex = 4;
            this.btnselect.Text = "选课";
            this.btnselect.UseVisualStyleBackColor = true;
            this.btnselect.Click += new System.EventHandler(this.btnselect_Click);
            // 
            // btnquery
            // 
            this.btnquery.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnquery.Location = new System.Drawing.Point(37, 153);
            this.btnquery.Name = "btnquery";
            this.btnquery.Size = new System.Drawing.Size(195, 73);
            this.btnquery.TabIndex = 3;
            this.btnquery.Text = "查询成绩";
            this.btnquery.UseVisualStyleBackColor = true;
            this.btnquery.Click += new System.EventHandler(this.btnquery_Click);
            // 
            // StudentMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnalter);
            this.Controls.Add(this.btnselect);
            this.Controls.Add(this.btnquery);
            this.Controls.Add(this.lblWelcome);
            this.Name = "StudentMain";
            this.Text = "学生首页";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnalter;
        private System.Windows.Forms.Button btnselect;
        private System.Windows.Forms.Button btnquery;
    }
}