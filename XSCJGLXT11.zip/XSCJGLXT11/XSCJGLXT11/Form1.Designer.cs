﻿namespace XSCJGLXT11
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStu = new System.Windows.Forms.Button();
            this.btnTea = new System.Windows.Forms.Button();
            this.btnAdm = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnStu
            // 
            this.btnStu.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnStu.Location = new System.Drawing.Point(28, 143);
            this.btnStu.Name = "btnStu";
            this.btnStu.Size = new System.Drawing.Size(195, 73);
            this.btnStu.TabIndex = 0;
            this.btnStu.Text = "学生";
            this.btnStu.UseVisualStyleBackColor = true;
            this.btnStu.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnTea
            // 
            this.btnTea.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnTea.Location = new System.Drawing.Point(285, 143);
            this.btnTea.Name = "btnTea";
            this.btnTea.Size = new System.Drawing.Size(195, 73);
            this.btnTea.TabIndex = 1;
            this.btnTea.Text = "教师";
            this.btnTea.UseVisualStyleBackColor = true;
            this.btnTea.Click += new System.EventHandler(this.btnTea_Click);
            // 
            // btnAdm
            // 
            this.btnAdm.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnAdm.Location = new System.Drawing.Point(551, 143);
            this.btnAdm.Name = "btnAdm";
            this.btnAdm.Size = new System.Drawing.Size(195, 73);
            this.btnAdm.TabIndex = 2;
            this.btnAdm.Text = "管理员";
            this.btnAdm.UseVisualStyleBackColor = true;
            this.btnAdm.Click += new System.EventHandler(this.btnAdm_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("黑体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(24, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(490, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "学生成绩管理系统欢迎您！请选择您的身份：";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAdm);
            this.Controls.Add(this.btnTea);
            this.Controls.Add(this.btnStu);
            this.Name = "Form1";
            this.Text = "首页";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStu;
        private System.Windows.Forms.Button btnTea;
        private System.Windows.Forms.Button btnAdm;
        private System.Windows.Forms.Label label1;
    }
}

