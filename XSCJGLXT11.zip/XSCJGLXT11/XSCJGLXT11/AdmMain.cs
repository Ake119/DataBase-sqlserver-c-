﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XSCJGLXT11
{
    public partial class AdmMain : Form
    {
        private string connectionString = "Data Source=. ; Initial Catalog=XSCJGL1; User ID=sa; Password=2004119; TrustServerCertificate=True";
        public AdmMain()
        {
            InitializeComponent();
        }

        private void btnmanage_Click(object sender, EventArgs e)
        {
            admmanage manage = new admmanage();
            manage.FormClosed += (s, args) => this.Show();
            manage.ShowDialog();
            this.Hide();
        }

        private void btnalter_Click(object sender, EventArgs e)
        {
            admalter alter = new admalter();
            alter.FormClosed += (s, args) => this.Show();
            alter.ShowDialog();
            this.Hide();
        }

        private void btnonoff_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();                   
                    string queryStatus = "SELECT 录入成绩开关 FROM 录入成绩";
                    SqlCommand queryCmd = new SqlCommand(queryStatus, conn);
                    int currentStatus = Convert.ToInt32(queryCmd.ExecuteScalar());

                    int newStatus = currentStatus == 1 ? 0 : 1;
                    string updateQuery = "UPDATE 录入成绩 SET 录入成绩开关 = @NewStatus";
                    SqlCommand updateCmd = new SqlCommand(updateQuery, conn);
                    updateCmd.Parameters.AddWithValue("@NewStatus", newStatus);

                    int result = updateCmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        string message = newStatus == 1 ? "已开启录入成绩功能" : "已关闭录入成绩功能";
                        MessageBox.Show(message);
                    }
                    else
                    {
                        MessageBox.Show("操作失败！");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("错误: " + ex.Message);
                }
            }
        }

        private void AdmMain_Load(object sender, EventArgs e)
        {

        }
    }
}
